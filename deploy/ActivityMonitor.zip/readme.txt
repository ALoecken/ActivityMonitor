To make this runnable, you need additional files:

 1. Go to https://code.google.com/p/java-universal-tween-engine/
  1. Download "tween-engine-api-6.3.3.zip" (maybe a newer version is also working)
  2. Extract zip and copy "tween-engine-api.jar" into "ActivityMonitor/lib"

 2. Go to https://code.google.com/p/jnativehook/
  1. Download "JNativeHook-1.1.4.zip" (maybe a newer version is also working)
  2. Extract zip and copy "jar/JNativeHook.jar" into "ActivityMonitor/lib"

 3. Go to http://sourceforge.net/projects/opendmxjavajni/
  1. Download "opendmx_bin01.zip" (from http://sourceforge.net/projects/opendmxjavajni/files/opendmx_bin/opendmx_bin01/ )
  2. Extract zip and copy "OpenDmx.jar" into "ActivityMonitor/lib"
  3. Copy dlls to "ActivityMonitor"
  
4. Go to http://mfizz.com/oss/rxtx-for-java
  1. Download Windows-x86 (mfz-rxtx-2.2-20081207-win-x86.zip)
  2. Extract zip and copy "RXTX.jar" into "ActivityMonitor/lib"
  3. Copy dlls to "ActivityMonitor"